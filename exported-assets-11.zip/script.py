import csv
from datetime import datetime, timedelta
import random

# Create sample CSV data for transaction import
sample_transactions = [
    ["Date", "Description", "Amount", "Account", "Category"],
    ["2025-06-01", "SALARY DEPOSIT - ACME CORP", "5000.00", "Checking", "Income"],
    ["2025-06-01", "RENT PAYMENT - PROPERTY MGT", "-1500.00", "Checking", "Housing"],
    ["2025-06-02", "STARBUCKS #1234 MAIN ST", "-5.47", "Credit Card", "Food & Dining"],
    ["2025-06-02", "SHELL GAS STATION #5678", "-45.30", "Credit Card", "Transportation"],
    ["2025-06-03", "KROGER GROCERY STORE", "-127.84", "Debit Card", "Groceries"],
    ["2025-06-03", "TARGET STORE #9012", "-89.99", "Credit Card", "Shopping"],
    ["2025-06-04", "NETFLIX SUBSCRIPTION", "-15.99", "Credit Card", "Entertainment"],
    ["2025-06-04", "ELECTRIC COMPANY BILL", "-89.50", "Checking", "Utilities"],
    ["2025-06-05", "CHIPOTLE MEXICAN GRILL", "-12.45", "Credit Card", "Food & Dining"],
    ["2025-06-05", "AMAZON PURCHASE", "-34.99", "Credit Card", "Shopping"],
    ["2025-06-06", "SPOTIFY PREMIUM", "-9.99", "Credit Card", "Entertainment"],
    ["2025-06-06", "MOBIL GAS STATION", "-38.75", "Credit Card", "Transportation"],
    ["2025-06-07", "WHOLE FOODS MARKET", "-156.22", "Debit Card", "Groceries"],
    ["2025-06-08", "FREELANCE PAYMENT", "750.00", "Checking", "Income"],
    ["2025-06-08", "WATER UTILITY BILL", "-45.30", "Checking", "Utilities"],
    ["2025-06-09", "MCDONALDS #3456", "-8.99", "Credit Card", "Food & Dining"],
    ["2025-06-10", "UBER RIDE", "-15.60", "Credit Card", "Transportation"],
    ["2025-06-10", "INTERNET BILL", "-79.99", "Checking", "Utilities"],
    ["2025-06-11", "SAVINGS TRANSFER", "-500.00", "Checking", "Savings"],
    ["2025-06-12", "CVS PHARMACY", "-23.45", "Credit Card", "Health"],
]

# Write to CSV file
with open('sample_transactions.csv', 'w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerows(sample_transactions)

print("Sample CSV file created successfully!")
print("File contains {} transactions with proper formatting for import.".format(len(sample_transactions)-1))

# Display first few rows for preview
print("\nPreview of CSV content:")
for i, row in enumerate(sample_transactions[:6]):
    print(f"Row {i+1}: {', '.join(row)}")

print("\nCSV Format Guidelines:")
print("- Date: MM/DD/YYYY or YYYY-MM-DD format")
print("- Description: Merchant/payee name")
print("- Amount: Positive for income, negative for expenses")
print("- Account: Bank account or card name")
print("- Category: Optional (app will auto-categorize if blank)")